import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class Member {
	private String memId;
	private String username;
	private String memName;
	private boolean isBlacklisted;
	private LocalDate blacklistUntil;

	public Member(String memId, String username, String memName, boolean isBlacklisted, LocalDate blacklistUntil) {
		super();
		this.memId = memId;
		this.username = username;
		this.memName = memName;
		this.isBlacklisted = isBlacklisted;
		this.blacklistUntil = blacklistUntil;
	}
	
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public boolean isBlacklisted() {
		return isBlacklisted;
	}
	public void setBlacklisted(boolean isBlacklisted) {
		this.isBlacklisted = isBlacklisted;
	}
	public LocalDate getBlacklistUntil() {
		return blacklistUntil;
	}
	public void setBlacklistUntil(LocalDate blacklistUntil) {
		this.blacklistUntil = blacklistUntil;
	}
	
	public static void registerMember(String username, String memName) {
        String sql = "INSERT INTO MEMBERS (memId, username, memName) VALUES (member_seq.NEXTVAL, ?, ?)";
        try {
        	Connection conn = JDBCon.getConnection();
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setString(1, username);
            psmt.setString(2, memName);
            psmt.executeUpdate();
            System.out.println("회원이 등록되었습니다.");
        } catch (SQLException e) {
            if (e.getErrorCode() == 1) {
                System.out.println("이미 존재하는 사용자 ID입니다.");
            } else {
            	System.out.println("회원 등록 중 오류발생");
                e.printStackTrace();
            }
        }
    }

	public static void setBlacklist(String username, boolean isBlacklisted, int blacklistDays) {
        String updateBlacklistSql = "UPDATE MEMBERS SET isBlacklisted = ?, blacklistUntil = SYSDATE + ? WHERE username = ?";
        try (Connection con = JDBCon.getConnection();
             PreparedStatement stmt = con.prepareStatement(updateBlacklistSql)) {
            stmt.setInt(1, isBlacklisted ? 1 : 0);
            stmt.setInt(2, blacklistDays);
            stmt.setString(3, username);
            stmt.executeUpdate();
            System.out.println(username + " 회원이 " + (isBlacklisted ? "블랙리스트에 추가되었습니다." : "블랙리스트에서 해제되었습니다."));
        } catch (SQLException e) {
            System.out.println("블랙리스트 설정 중 오류 발생");
            e.printStackTrace();
        }
    }

    public static void checkAndUpdateBlacklist() {
        String sql = "SELECT * FROM MEMBERS WHERE isBlacklisted = 1";
        try (Connection conn = JDBCon.getConnection();
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("=========블랙리스트 회원 정보=========");
            while (rs.next()) {
            	int memberId = rs.getInt("memId");
            	String user = rs.getString("username");
            	String memberName = rs.getString("memName");
            	
            	System.out.println("회원번호 :  " + memberId + " , 회원 ID : " + user + " , 회원 이름 : " + memberName);
            }
            System.out.println("블랙회원들은 정해진 날에 블랙리스트가 해제됩니다.");
        } catch (SQLException e) {
        	System.out.println("블랙리스트 체크 중 문제 발생");
            e.printStackTrace();
        }
    }
}
