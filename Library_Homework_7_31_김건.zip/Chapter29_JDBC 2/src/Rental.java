import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Rental {
	private int rentId;
	private int bookId;
	private String username;
	private LocalDate rentalDate;
	private LocalDate returnDate;
	private LocalDate actualReturnDate;
	private boolean isExtended;
	public Rental(int rentId, int bookId, String username, LocalDate rentalDate, LocalDate returnDate,
			LocalDate actualReturnDate, boolean isExtended) {
		super();
		this.rentId = rentId;
		this.bookId = bookId;
		this.username = username;
		this.rentalDate = rentalDate;
		this.returnDate = returnDate;
		this.actualReturnDate = actualReturnDate;
		this.isExtended = isExtended;
	}
	public int getRentId() {
		return rentId;
	}
	public void setRentId(int rentId) {
		this.rentId = rentId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public LocalDate getRentalDate() {
		return rentalDate;
	}
	public void setRentalDate(LocalDate rentalDate) {
		this.rentalDate = rentalDate;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public LocalDate getActualReturnDate() {
		return actualReturnDate;
	}
	public void setActualReturnDate(LocalDate actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}
	public boolean isExtended() {
		return isExtended;
	}
	public void setExtended(boolean isExtended) {
		this.isExtended = isExtended;
	}
	
	public static void rentBook(String username, String bookTitle) {
	    try (Connection con = JDBCon.getConnection()) {
	    	con.setAutoCommit(false);
	        try {
	            int memberId = getMemberId(con, username);
	            if (memberId == -1) {
	                System.out.println("해당 사용자를 찾을 수 없습니다.");
	                return;
	            }

	            if (isBlacklisted(con, memberId)) {
	                System.out.println("블랙리스트 회원은 대여할 수 없습니다.");
	                return;
	            }

	            int bookId = getAvailableBookId(con, bookTitle);
	            if (bookId == -1) {
	                System.out.println("해당 책을 찾을 수 없거나 모든 책이 대여 중입니다.");
	                return;
	            }

	            updateBookQuantity(con, bookId);
	            insertRentalRecord(con, bookId, memberId);

	            con.commit();
	            System.out.println("책이 성공적으로 대여되었습니다. 반납 예정일: " + LocalDate.now().plusDays(7));
	        } catch (SQLException e) {
	        	System.out.println("대여 처리중 오류가 발생하였습니다.");
	        	con.rollback();
	            throw e;
	        }
	    } catch (SQLException e) {
	        System.out.println("대여 처리 중 오류가 발생했습니다: " + e.getMessage());
	    }
	}

	private static int getMemberId(Connection con, String username) throws SQLException {
	    String sql = "SELECT memId FROM MEMBERS WHERE username = ?";
	    try (PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setString(1, username);
	        ResultSet rs = stmt.executeQuery();
	        return rs.next() ? rs.getInt("memId") : -1;
	    }
	}

	private static boolean isBlacklisted(Connection con, int memId) throws SQLException {
	    String sql = "SELECT isBlacklisted FROM MEMBERS WHERE memId = ?";
	    try (PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setInt(1, memId);
	        ResultSet rs = stmt.executeQuery();
	        return rs.next() && rs.getInt("isBlacklisted") == 1;
	    }
	}

	private static int getAvailableBookId(Connection con, String bookTitle) throws SQLException {
	    String sql = "SELECT bookId FROM BOOKS WHERE bookTitle = ? AND bookCount > 0";
	    try (PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setString(1, bookTitle);
	        ResultSet rs = stmt.executeQuery();
	        return rs.next() ? rs.getInt("bookId") : -1;
	    }
	}

	private static void updateBookQuantity(Connection con, int bookId) {
	    String sql = "UPDATE books SET bookCount = bookCount -1 WHERE bookId = ?";
	    try (PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setInt(1, bookId);
	        stmt.executeUpdate();
	    } catch (SQLException e) {
	    	System.out.println("책 갯수 업데이트에서 문제발생");
	    	e.printStackTrace();
	    }
	}

	private static void insertRentalRecord(Connection con, int bookId, int memId) {
	    String sql = "INSERT INTO RENTALS (rentId, bookId, memId, rentalDate, returnDate, isExtended) VALUES (rental_seq.NEXTVAL, ?, ?, SYSDATE, SYSDATE + 7, 0)";
	    try (PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setInt(1, bookId);
	        stmt.setInt(2, memId);
	        stmt.executeUpdate();
	    } catch (Exception e) {
	    	System.out.println("대여 기록 삽입 중 문제 발생");
	    	e.printStackTrace();
	    }
	}



	public static void returnBook(String username, String bookTitle) {
	    try (Connection con = JDBCon.getConnection()) {
	        con.setAutoCommit(false);

	        // 대여 정보 조회 쿼리
	        String rentalSql = "SELECT r.rentId, r.bookId, r.returnDate, b.bookCount, m.memId " +
	                           "FROM RENTALS r " +
	                           "JOIN MEMBERS m ON r.memId = m.memId " +
	                           "JOIN BOOKS b ON r.bookId = b.bookId " +
	                           "WHERE m.username = ? AND b.bookTitle = ? AND r.actualReturnDate IS NULL";
	        try (PreparedStatement rentalStmt = con.prepareStatement(rentalSql)) {
	            rentalStmt.setString(1, username);
	            rentalStmt.setString(2, bookTitle);
	            ResultSet rentalRs = rentalStmt.executeQuery();

	            if (!rentalRs.next()) {
	                System.out.println("해당 대여 정보를 찾을 수 없습니다.");
	                return;
	            }

	            // 대여 정보 가져오기
	            int rentalId = rentalRs.getInt("rentId");
	            int bookId = rentalRs.getInt("bookId");
	            Date returnDate = rentalRs.getDate("returnDate");
	            int memberId = rentalRs.getInt("memId");

	            // 연체 확인 및 처리
	            LocalDate actualReturnDate = LocalDate.now();
	            LocalDate expectedReturnDate = returnDate.toLocalDate();
	            long daysOverdue = ChronoUnit.DAYS.between(expectedReturnDate, actualReturnDate);

	            if (daysOverdue > 0) {
	                System.out.println("연체되었습니다. 연체일수: " + daysOverdue + "일");
	                int blacklistDays = (int) daysOverdue * 2;
	                Member.setBlacklist(username, true, blacklistDays);
	            }

	            // 대여 정보 업데이트 쿼리
	            String updateRentalSql = "UPDATE RENTALS SET actualReturnDate = SYSDATE WHERE rentId = ?";
	            try (PreparedStatement updateRentalStmt = con.prepareStatement(updateRentalSql)) {
	                updateRentalStmt.setInt(1, rentalId);
	                updateRentalStmt.executeUpdate();
	            }

	            // 책 재고 업데이트 쿼리
	            String updateBookSql = "UPDATE BOOKS SET bookCount = bookCount + 1 WHERE bookId = ?";
	            try (PreparedStatement updateBookStmt = con.prepareStatement(updateBookSql)) {
	                updateBookStmt.setInt(1, bookId);
	                updateBookStmt.executeUpdate();
	            }

	            con.commit();
	            System.out.println("책이 성공적으로 반납되었습니다.");
	        }
	    } catch (SQLException e) {
	        System.out.println("반납 과정에서 오류 발생");
	        e.printStackTrace();
	    }
	}
    
	public static void extendRental(String username, String bookTitle) {
	    try (Connection con = JDBCon.getConnection()) {
	        con.setAutoCommit(false);

	        // 대여 연장 가능 여부 확인 쿼리
	        String checkSql = "SELECT r.rentId, r.returnDate, r.isExtended " +
	                          "FROM RENTALS r " +
	                          "JOIN MEMBERS m ON r.memId = m.memId " +
	                          "JOIN BOOKS b ON r.bookId = b.bookId " +
	                          "WHERE m.username = ? AND b.bookTitle = ? AND r.actualReturnDate IS NULL";
	        try (PreparedStatement checkStmt = con.prepareStatement(checkSql)) {
	            checkStmt.setString(1, username);
	            checkStmt.setString(2, bookTitle);
	            ResultSet rs = checkStmt.executeQuery();

	            if (rs.next()) {
	                int rentalId = rs.getInt("rentId");
	                Date returnDate = rs.getDate("returnDate");
	                boolean isExtended = rs.getInt("isExtended") == 1;

	                if (isExtended) {
	                    System.out.println("이미 연장된 대여입니다. 더 이상 연장할 수 없습니다.");
	                    return;
	                }

	                // 대여 연장
	                String extendSql = "UPDATE RENTALS SET returnDate = returnDate + 7, isExtended = 1 WHERE rentId = ?";
	                try (PreparedStatement extendStmt = con.prepareStatement(extendSql)) {
	                    extendStmt.setInt(1, rentalId);
	                    extendStmt.executeUpdate();
	                }

	                con.commit();
	                System.out.println("대여가 성공적으로 1주일 연장되었습니다. 새로운 반납 예정일: " + returnDate.toLocalDate().plusDays(7));
	            } else {
	                System.out.println("해당 대여 정보를 찾을 수 없습니다.");
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println("대여 연장 과정에서 오류 발생");
	        e.printStackTrace();
	    }
	}

	public static void checkOverdueBooks(String username) {
        String sql = "SELECT r.rentId, r.returnDate " +
                     "FROM RENTALS r " +
                     "JOIN MEMBERS m ON r.memId = m.memId " +
                     "WHERE m.username = ? AND r.actualReturnDate IS NULL";

        try (Connection con = JDBCon.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int rentId = rs.getInt("rentId");
                LocalDate returnDate = rs.getDate("returnDate").toLocalDate();
                LocalDate currentDate = LocalDate.now();
                long daysOverdue = currentDate.until(returnDate).getDays();

                if (daysOverdue > 0) {
                    System.out.println("연체된 책 ID: " + rentId + ", 연체일수: " + daysOverdue + "일");
                    // 여기에 추가적인 연체 처리 로직을 넣으세요 (예: 블랙리스트 추가)
                }
            }
        } catch (SQLException e) {
            System.out.println("연체 도서 확인 중 오류 발생");
            e.printStackTrace();
        }
    }
}
