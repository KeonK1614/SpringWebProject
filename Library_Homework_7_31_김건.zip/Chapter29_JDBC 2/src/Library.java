import java.util.InputMismatchException;
import java.util.Scanner;

public class Library {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
        	while (true) {
                displayMenu();
                int choice = getUserChoice();
                processChoice(choice);
            }
        } catch (InputMismatchException e) {
        	e.printStackTrace();
        }
    	
    }

    private static void displayMenu() {
        System.out.println("\n===== 도서관 관리 시스템 =====");
        System.out.println("1. 책 등록");
        System.out.println("2. 책 삭제");
        System.out.println("3. 책 조회");
        System.out.println("4. 전체 책 목록");
        System.out.println("5. 회원 가입");
        System.out.println("6. 책 대여");
        System.out.println("7. 책 반납");
        System.out.println("8. 대여 연장");
        System.out.println("9. 연체 도서 확인");
        System.out.println("10. 블랙리스트 관리");
        System.out.println("11. 종료");
        System.out.print("원하는 작업을 선택하세요: ");
    }

    private static int getUserChoice() {
        return scanner.nextInt();
    }

    private static void processChoice(int choice) {
        switch (choice) {
            case 1:
                registerBook();
                break;
            case 2:
                deleteBook();
                break;
            case 3:
                searchBook();
                break;
            case 4:
                listAllBooks();
                break;
            case 5:
                registerMember();
                break;
            case 6:
                rentBook();
                break;
            case 7:
                returnBook();
                break;
            case 8:
                extendRental();
                break;
            case 9:
            	showOverdueBooks();
            	break;
            case 10:
            	checkBlacklisted();
            	break;
            case 11:
                System.out.println("프로그램을 종료합니다.");
                System.exit(0);
            default:
                System.out.println("잘못된 선택입니다. 다시 선택해주세요.");
        }
    }

    private static void registerBook() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("책 제목을 입력하세요: ");
        String title = scanner.nextLine();
        System.out.print("책 수량을 입력하세요: ");
        int quantity = scanner.nextInt();
        Book.registerBook(title, quantity);
    }

    private static void deleteBook() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("삭제할 책의 id를 입력하세요: ");
        int bookId = scanner.nextInt();
        Book.deleteBook(bookId);
    }

    private static void searchBook() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("검색할 책의 제목을 입력하세요: ");
        String title = scanner.nextLine();
        Book.findBook(title);
    }

    private static void listAllBooks() {
        Book.findAllBooks();
    }

    private static void registerMember() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("사용자 ID를 입력하세요: ");
        String username = scanner.nextLine();
        System.out.print("이름을 입력하세요: ");
        String name = scanner.nextLine();
        Member.registerMember(username, name);
    }

    private static void rentBook() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("사용자 ID를 입력하세요: ");
        String username = scanner.nextLine();
        System.out.print("대여할 책의 제목을 입력하세요: ");
        String title = scanner.nextLine();
        Rental.rentBook(username, title);
    }

    private static void returnBook() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("사용자 ID를 입력하세요: ");
        String username = scanner.nextLine();
        System.out.print("반납할 책의 제목을 입력하세요: ");
        String title = scanner.nextLine();
        Rental.returnBook(username, title);
    }
    
    private static void extendRental() {
        scanner.nextLine(); // 버퍼 비우기
        System.out.print("사용자 ID를 입력하세요: ");
        String username = scanner.nextLine();
        System.out.print("연장할 책의 제목을 입력하세요: ");
        String title = scanner.nextLine();
        Rental.extendRental(username, title);
    }
    
    private static void showOverdueBooks() {
    	scanner.nextLine();
    	System.out.println("사용자 ID를 입력하세요: ");
    	String username = scanner.nextLine();
    	System.out.println(username+"님의 지금까지 연체 된 책들입니다.");
    	Rental.checkOverdueBooks(username);
    }
    
    private static void checkBlacklisted() {
    	System.out.println("블랙리스트 관련 정보입니다.");
    	Member.checkAndUpdateBlacklist();
    }
}