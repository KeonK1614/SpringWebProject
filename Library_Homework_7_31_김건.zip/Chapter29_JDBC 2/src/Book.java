import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Book {
	private int bookId;
	private String bookTitle;
	private int bookCount;
	
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public int getBookCount() {
		return bookCount;
	}
	public void setBookCount(int bookCount) {
		this.bookCount = bookCount;
	}
	
	public Book (int bookId, String bookTitle, int bookCount) {
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookCount = bookCount;
	}
	
    public static void registerBook(String title, int quantity) {
    	System.out.println("");
        String sql = "INSERT INTO books (bookId, bookTitle, bookCount) VALUES (book_seq.NEXTVAL, ?, ?)";
        try {
        	Connection con = JDBCon.getConnection();
        	PreparedStatement psmt = con.prepareStatement(sql);
        	psmt.setString(1, title);
        	psmt.setInt(2, quantity);
        	psmt.executeUpdate();
            System.out.println("책이 등록되었습니다.");
        } catch (SQLException e) {
        	System.out.println("책 등록 과정에서 오류 발생");
            e.printStackTrace();
        }
    }

    public static void deleteBook(int bookId) {
        String sql = "DELETE FROM books WHERE bookId = ?";
        try {
        	Connection con = JDBCon.getConnection();
            PreparedStatement psmt = con.prepareStatement(sql);
            psmt.setInt(1, bookId);
            int deletingBookTitle = psmt.executeUpdate();
            if (deletingBookTitle > 0) {
                System.out.println("책이 삭제되었습니다.");
            } else {
                System.out.println("해당 ID의 책을 찾을 수 없습니다.");
            }
        } catch (SQLException e) {
        	System.out.println("오래된 책 버리는 데 오류 발생");
            e.printStackTrace();
        }
    }
    
    public static void findBook(String bookTitle) {
    	String sql = "SELECT * from books where bookTitle LIKE ?";
    	try {
    		Connection con = JDBCon.getConnection();
            PreparedStatement psmt = con.prepareStatement(sql);
            psmt.setString(1, "%" + bookTitle + "%");
            ResultSet rs = psmt.executeQuery();
            
            while (rs.next()) {
				System.out.println("ID: " + rs.getInt("bookId") +
									", 제목: " + rs.getString("bookTitle") +
									", 책 수량: " + rs.getInt("bookCount"));
			}
            
    	} catch (Exception e) {
    		System.out.println("책 조회 중 오류 발생");
    		e.printStackTrace();
    	}
    }
    
    public static void findAllBooks() {
    	String sql = "SELECT * FROM books";
    	try {
    		Connection con = JDBCon.getConnection();
            Statement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
				System.out.println("ID: " + rs.getInt("bookId") +
									", 제목: " + rs.getString("bookTitle") +
									", 책 수량: " + rs.getInt("bookCount"));
			}
            
		} catch (Exception e) {
			System.out.println("책 전체 조회 중 오류 발생");
			e.printStackTrace();
		}
    }

}
