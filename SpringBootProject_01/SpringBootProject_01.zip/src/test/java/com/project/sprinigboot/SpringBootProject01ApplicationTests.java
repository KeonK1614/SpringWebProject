package com.project.sprinigboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProject01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
