package com.project.springboot.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.springboot.dto.BoardInfoDto;

@Service
public class BoardInfoService {
//	@Autowired
//	private IBoardInfoDao boardInfoDao;
//	
//	public List<BoardInfoDto> searchBoardInfo(BoardSearch criteria) {
//		return boardInfoDao.searchBoardInfo(criteria);
//	}
}
